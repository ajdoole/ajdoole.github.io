 /*
  * 
  * EGR 314
  * HMI Subsystem for team 204
  * By: Jake Strube
  * 
  * 
  * 
  * 
*/


//#include <stdbool.h>
//#include <stdint.h>
#include <stdio.h>

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "mcc_generated_files/uart/eusart1.h"
#include "ssd1306.h"


uint16_t ms=0;
uint16_t sec=0;


// Callback function to increment the timer to have milliseconds and seconds and blink the LED every second
void timer_callback(void)
{
    ms++;
    if (ms>1000) 
    {
        ms -= 1000;
        sec++;
        //IO_RD6_Toggle();
    }
}

void eusart_callback(void)
{
//    ms++;
}
// Send the message function
uint8_t send_message(char * my_message){
    printf("%s",my_message);
    return 1;
}
        

#define BUFSIZE 16
#define MSGSIZE 64
#define TEAMSIZE 4
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

const char my_id='S';
const char team_ids[TEAMSIZE+1]="ADSWX";
char buffer_in[BUFSIZE+1];
char message_in[MSGSIZE+1];
char message_out[MSGSIZE+1];
unsigned int message_me=0;
unsigned int processing = 0;

//char stream_in[]="-----AZcb34567890YB-----------AZcd34567890YB--AZed34567890YB--AZdz34567890YB---AZed1234567890123456789012345678901234567890123456789012345678YB-";
//char read_char(void){
//    static int ii=0;
//    char c = stream_in[ii];
//    ii++;
//    if (ii>=(sizeof stream_in)-1)
//    {ii=0;}
//    return c;
//}

void fill_string(char * mystring,char value,unsigned int size){
    for (int ii=0;ii<size;ii++){
        mystring[ii]=value;
    }
}

unsigned int find_char(char * mystring, char value,unsigned int size){
    char c=0;
    for (int ii=0;ii<size;ii++){
        c= mystring[ii];
        //printf("%c,%c;",value,mystring[ii]);
        if (c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(unsigned int ii){
    message_in[ii-2]=0;
    if (message_me == 1){
        processing = 1;
    }
    else{
         printf("AZSWPIC: handling: %sYB \n",message_in+4);
    }
}


int main(void)
{

    
    
    char c=0;
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    buffer_in[BUFSIZE]=0;
    message_in[MSGSIZE]=0;
    unsigned int message_incoming=0;
    unsigned int message_me=0;
    unsigned int processing = 0;

    fill_string(buffer_in,'a',BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE]=MSGTESTCHAR;
    
    // Sets my_id as a char so I can compare incoming messages
    char me = 0;
    me = my_id;

    uint16_t ms_last=0;
    uint16_t sec_last=0;
    SYSTEM_Initialize();
    ADC_Initialize();
    ssd1306_init(0x3C);
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    TMR1_Initialize();
    TMR1_Start();
    TMR1_TMRInterruptEnable();

    TMR1_OverflowCallbackRegister(timer_callback);

    EUSART1_Initialize();
    EUSART1_Enable();
//    EUSART1_TransmitEnable();
//    EUSART1_ReceiveEnable();
//    EUSART1_TransmitInterruptEnable();
//    EUSART1_ReceiveInterruptEnable();
//    
//    EUSART1_RxCompleteCallbackRegister(eusart_callback);
    
    ADC_ChannelSelect(ADC_CHANNEL_ANB1);
    ADC_ConversionStart();
        
        
//    printf("%lu", sizeof buffer_in);
    //ssd1306_clear(); // Used to get rid of the noise when starting up the OLED screen
    while(1)
    {
//        IO_RD6_SetHigh();
//        IO_RD5_SetHigh();
        
        if(EUSART1_IsRxReady())
        {
            c= EUSART1_Read(); // Read the incoming UART 
            buffer_in[buffer_ii]=c; // Set the UART character into the buffer
            // Checking for the start of a message
            if (buffer_in[buffer_last_ii]=='A' & buffer_in[buffer_ii]=='Z')
            {
                printf("PIC: message start \n");
                fill_string(message_in,'_',MSGSIZE);
                message_in[MSGTESTSIZE]=MSGTESTCHAR;
                message_incoming=1;
                message_in[0] = buffer_in[buffer_last_ii];
                message_ii=1;
            }
            // Checking for the end of the message
            if (buffer_in[buffer_last_ii]=='Y' & buffer_in[buffer_ii]=='B')
            {
                printf("PIC: message end \n");
                message_incoming=0;
                message_in[message_ii] = buffer_in[buffer_ii];
                message_last_ii= message_ii;
                message_ii = message_ii+1;
                handle_message(message_ii);
                IO_RD5_Toggle();
            }
            if (message_incoming!=0){
                message_in[message_ii] = buffer_in[buffer_ii];
                //printf("AZSWPIC: Full Message: %s YB", message_in);

                // Checking the sender
                if (message_ii==2)
                {
                    unsigned result = 0;
                    char a=0;
                    a = message_in[message_ii];
                    result= find_char(team_ids,a,TEAMSIZE);
                    // Sender is not in the team
                    if (result==0)
                    {
                        printf("PIC: sender not in team deleting message \n");
                        message_incoming = 0; // Set incoming message status to no message incoming
                        message_ii=0; // Restarts the message buffer
                    } 
                    // Sender is in team
                    else 
                    {
                        printf("PIC: sender in team \n");
                        char me = 0;
                        me = my_id;
                        // If i am the sender
                        if (me == a)
                        {
                            printf("PIC: Sender is me deleting message \n");
                            message_incoming = 0; // Set incoming message status to no message incoming
                            message_ii=0; // Restarts the message buffer
                        }
                        // If i am not the sender
                        else 
                        {
                            printf("PIC: Sender not me \n");
                        }
                        
                    }
                }
                
                // Checking the receiver
                if (message_ii==3)
                {
                    unsigned result = 0;
                    char d=0;
                    d = message_in[message_ii];
                    result= find_char(team_ids,d,TEAMSIZE);
                    
                    // Receiver is not in team
                    if (result==0){
                        printf("PIC: receiver not in team deleting \n");
                        message_incoming = 0; // Set incoming message status to no message incoming
                        message_ii=0; // Restarts the message buffer
                    } 
                    // Receiver is in team
                    else {
                        printf("PIC: receiver in team \n");
                        // Receiver is me
                        if (me == d){
                            printf("PIC: receiver is me \n");
                            message_me = 1;
                        }
                        // Receiver is not me
                        else{
                            printf("PIC: receiver is not me \n");
                            message_me = 0;
                        }
                    }
                }
                
                if (processing == 1){
                    printf("PIC: Message Processing \n");
                    if (message_ii == 4){
                        char i=0;
                        i = message_in[message_ii];
                        // If the message identifier is 0
                        if (i == '0'){ 
                            printf("PIC: Processing incoming message 0 \n");
                            ssd1306_clear();
                            ssd1306_string_pos(0, 0, "Message Type 0");
                            message_me = 0;
                            processing = 0;
                        }
                        // If the message identifier is 5
                        if (i == '5'){
                            printf("PIC: Processing incoming message 5 \n");
                            ssd1306_clear();
                            ssd1306_string_pos(0, 0, "Message Type 5");
                            message_me = 0;
                            processing = 0;
                        }
                        // If the message identifier is 6
                        if (i == '6'){
                            printf("PIC: Processing incoming message 6 \n");
                            ssd1306_clear();
                            ssd1306_string_pos(0, 0, "Message Type 6");
                            message_me = 0;
                            processing = 0;
                        }
                        // If the message identifier is 7
                        if (i == '7'){
                            printf("PIC: Processing incoming message 7 \n");
                            ssd1306_clear();
                            ssd1306_string_pos(0, 0, "Message Type 7");
                            message_me = 0;
                            processing = 0;
                        }
                        // If the message identifier is 8
                        if (i == '8'){
                            printf("PIC: Processing incoming message 8 \n");
                            ssd1306_clear();
                            ssd1306_string_pos(0, 0, "Message Type 8");
                            message_me = 0;
                            processing = 0;
                        }
                        else{
                            printf("PIC: Identifier not known \n");
                            ssd1306_clear();
                            ssd1306_string_pos(0, 0, "Message Type 0");
                            message_me = 0;
                            processing = 0;
                        }
                    }
                }
                
                message_last_ii= message_ii; // set the current message slot to the last message slot in the buffer
                message_ii = message_ii+1; // Increment the message in buffer to the next slot

                // Handling messages that are to long
                if (message_ii<MSGTESTSIZE){} else{
                    printf("PIC: message too large. deleting \n");
                    message_incoming = 0; // Set incoming message status to no message incoming
                    message_ii=0; // Restarts the message buffer
                }
            }
            buffer_last_ii= buffer_ii;
            buffer_ii = (buffer_ii+1)%BUFSIZE;
        }
        
        
        // Message Identifier byte

        
//        if ((sec%3==0) & (sec!=sec_last)){
//            sprintf(message_out,"AZbaPIC: Heartbeat %u YB",sec);
//            send_message(message_out);
////            printf("AZbaPIC: Heartbeat %u YB",sec);
//        }
        
//        if (IO_RA6_GetValue()!=0)
//        {return 1;}
//        
        // Activate the OLED screen on the RED button
        // For position
        if (IO_RE2_GetValue() == 1)
        {
            IO_RD6_Toggle();
            ssd1306_clear();
            ssd1306_setscale(0);
            ssd1306_string_pos(0, 0, "This is a test");
            ssd1306_setscale(0);
            ssd1306_string_pos(10, 2, "10, 2"); // (X,Y, "String")
            ssd1306_string_pos(6, 7, "6, 7");
        }
        if(IO_RA0_GetValue()==1)
        {
            IO_RD5_Toggle();
            ssd1306_clear();
            ssd1306_setscale(0);
            ssd1306_string_pos(0,0,"Test screen 2");
            ssd1306_string_pos(123,7,"!"); // Furthest it can go without moving to the top again
            
            
            //Invert color every second
//            ssd1306_invert(1);
//            __delay_ms(1000);
//            ssd1306_invert(0);
        }
       
//        if (IO_RE2_GetValue()==0)
//        {IO_RD6_SetLow();}
//        if (IO_RE2_GetValue()==1)
//        {IO_RD6_SetHigh();}
//        if (IO_RA7_GetValue()==1)
//        {IO_RD5_SetHigh();}
//        
//        if (IO_RA7_GetValue()!=0)
//        {IO_RD5_SetLow();}
        if (IO_RA6_GetValue()!=0)
        {return 1;}
        
//        ADC_ChannelSelect(ADC_CHANNEL_ANB1);
//        ADC_ConversionStart();
//        
//        while (!ADC_IsConversionDone());
//        
//        int16_t adcValue = ADC_ConversionResultGet();
//        
//        adcValue = (adcValue/1023)*100;
//        
//        if (0 < adcValue < 10){
//            IO_RD6_Toggle();
//            __delay_ms(1000);
//        }
//        if(adcValue > 10){
//            IO_RD6_SetLow();
//        }
        
        sec_last = sec;
        ms_last = ms;
        
    }
}
